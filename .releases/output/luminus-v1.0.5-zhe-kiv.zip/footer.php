    <?php get_template_part('template-parts/footer/footer'); ?>
    <!-- Bootstrap 5.0.2 Bundle with Popper -->
    <script src="<?= get_template_directory_uri() . '/assets/vendors/bootstrap-5.0.2/js/bootstrap.bundle.min.js' ?>" ></script>
    <script src="<?= get_template_directory_uri() . '/assets/vendors/fontawesome-6.5.1/js/all.min.js' ?>" ></script>
    <?php wp_footer(); ?>
  </body>
</html>