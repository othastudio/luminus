<?php get_header(); ?>
<div class="container mt-5">
    <div class="row">
        <div class="co text-center">
            <h2>404, Page not found!</h2>
            <p>We are sorry! this page was not found.</p>
        </div>
    </div>
</div>
<?php get_footer(); ?>