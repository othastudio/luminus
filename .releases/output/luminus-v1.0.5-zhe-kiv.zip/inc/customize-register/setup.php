<?php
// Include external functions
require_once(get_template_directory() . '/inc/customize-register/maintenance-mode.php');
require_once(get_template_directory() . '/inc/customize-register/footer-copyright.php');
require_once(get_template_directory() . '/inc/customize-register/social-medias.php');
require_once(get_template_directory() . '/inc/customize-register/seo-settings.php');