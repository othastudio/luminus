function entry(){
    console.log("Welcome to Luminus");
}
entry();