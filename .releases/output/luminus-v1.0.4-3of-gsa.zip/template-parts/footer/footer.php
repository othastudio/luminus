<footer class="bg-dark">
    <div class="container">
        <div class="row align-items-center pt-3">
            <div class="col">
                <p class="text-left text-muted"><?= luminus_display_footer_copyright();  ?></p>
            </div>
            <div class="col d-flex justify-content-end">
                <?= luminus_display_footer_menu(); ?>
                <?= luminus_display_social_medias() ?>
            </div>
        </div>
    </div>
</footer>