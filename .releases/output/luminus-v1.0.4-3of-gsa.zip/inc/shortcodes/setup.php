<?php
// Include external functions
require_once(get_template_directory() . '/inc/shortcodes/breadcrumb.php');
require_once(get_template_directory() . '/inc/shortcodes/social-share-buttons.php');